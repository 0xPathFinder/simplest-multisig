Student: Hryhoriuk Dmytro
Student Number: 301270139

mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1

# Usage

npm init -y

npm i express mongoose cors

npm i --save-dev nodemon

npm run devStart