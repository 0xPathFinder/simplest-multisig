const express = require('express');
const router = express.Router();
const productController = require('./productController');

router.get('/api/products', productController.getProducts);
router.get('/api/products/:id', productController.getProductById);
router.post('/api/products', productController.addProduct);
router.put('/api/products/:id', productController.updateProduct);
router.delete('/api/products/:id', productController.deleteProduct);
router.delete('/api/products', productController.deleteAllProducts);
router.get('/api/products', productController.findProductsByName);

module.exports = router;
