const express = require('express');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Welcome to DressStore application.' });
});

// for testing purposes
app.get('/api/products', (req, res) => {
  res.status(200).send({
    productsList: [
      {
        id: 1,
        name: 'T-Shirt',
        description: 'Black T-Shirt',
        price: 19.99,
        quantity: 10
      }
    ]
  })
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});